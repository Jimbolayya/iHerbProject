# Program by: James Vandermost
#
# 	This program takes in a log.txt file, counts the number of bytes each unique
# user has downloaded, then outputs the results to the results.txt file.
import re

# Declare Variables
objs = list()
idExists = 0
i = 0
j = 0
k = 0
l = 0

# Create customer class
class Customer:
	def __init__(self, customerID, bytesDownloaded):
		self.customerID = customerID
		self.bytesDownloaded = bytesDownloaded

# Open the log file and results file
logFile = open("log.txt", 'r')
results = open("results.txt", 'w+')
lines = logFile.readlines()

# Parse each line in the log
for line in lines:

	# Check the line to see if it contains CustomerId or Size
	customerMatch = re.findall(r'\bCustomerId:\d*', line)
	sizeMatch = re.findall(r'\bSize:\d*', line)

	# If line contains customer id, either add it to customer list or find it in the list
	if customerMatch:
		cID = customerMatch[0]
		cID = cID.split(':')
		cID = cID[1]
		idExists = 0

		# Check if CustomerID exists. If it does, set its position to k
		for obj in objs:
			if objs[j].customerID == cID:
				idExists = 1
				k = j
			j += 1

		# Reset j for next loop
		j = 0

		# If CustomerID does NOT exist, add it to the list
		if idExists == 0:
			objs.append(Customer(cID,0))

	# If line contains size, add the bytes to the user's total
	if sizeMatch:
		size = sizeMatch[0]
		size = size.split(':')
		size = size[1]
		size = int(size)

		if idExists == 1:
			objs[k].bytesDownloaded += size
		else:
			objs[i].bytesDownloaded = size
			i += 1

# Output results to results.txt
for obj in objs:
	results.write('CustomerID:' + objs[l].customerID + ' downloaded ' + str(objs[l].bytesDownloaded) + ' bytes' + '\n')
	l += 1

# Close files
results.close()
logFile.close()